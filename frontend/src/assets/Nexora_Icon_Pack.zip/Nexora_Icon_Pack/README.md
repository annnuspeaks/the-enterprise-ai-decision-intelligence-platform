# Nexora Icon Pack

Circular Nexora N emblem, prepared for web, mobile, and desktop use.

## Included

- `web/png/` — common favicon/PWA PNG sizes
- `web/ico/favicon.ico` — multi-size browser ICO
- `web/svg/nexora-icon.svg` — scalable SVG wrapper
- `apple/` — Apple Touch Icon
- `android/` — Android launcher density sizes + Play Store assets
- `desktop/windows/` — Windows desktop sizes
- `desktop/macos/` — macOS sizes
- `manifest/` — PWA manifest and browser configuration
- `master/` — 1024×1024 master PNG

The icon is circular, uses the Nexora N emblem, and has transparency outside the circle.
